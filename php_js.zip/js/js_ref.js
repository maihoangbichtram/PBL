var er_path = '../er';
var html_path = '..';
var db_path = '../db';
var img_path = '../img';