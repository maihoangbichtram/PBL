<?php
	$page_limit = 10;
	$page_max = 7;
	
	$img_path = '../img';
	$js_path = '../js';
?>