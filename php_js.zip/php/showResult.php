<?php 
	require_once('php_ref.php'); 
	session_start();
?>
<html>
	<head>
		<meta charset='utf-8'>
		<title>All results</title>
		<link rel="stylesheet" href="../css/style.css">
		<style>
			body {
				position:relative;
				background: #333 url(<?php echo $img_path;?>/bg.png) repeat;
				color: white;
				margin: 30px 30px 30px 30px;
			}
		</style>
	</head>
	<body>
		<label id='query' style='background:#E1B42B; border-radius: 5px; padding: 8px; font-size: 18px;'></label>
		<div id='result' style='margin-top: 25px;'>
			
		</div>
		<script src="https://code.jquery.com/jquery-3.2.1.js"></script>
		<script>
			$(document).ready(function() {
				$('#query').html('<?php echo $_SESSION['query'];?>');
				var id = <?php if(isset($_GET['id'])) echo $_GET['id']; else echo 0;?>;
				$.ajax({
					type: "GET",
					dataType: "json",
					url: "https://localhost:3000/" + '<?php echo $_SESSION['query'];?>',
					success:function(data) {
						var myBooks = [];
						//myBooks.push(data.row);
						myBooks = data.row;
						console.log(myBooks);	
						console.log(myBooks.length);	
						//console.log(data[0]);
						//console.log(data.ID);
						
						var count = 1;
						var col = [];
						for (var i = 0; i < myBooks.length; i++) {
							for (var key in myBooks[i]) {
								//console.log(key);
								if (col.indexOf(key) === -1) {
									col.push(key);
								}
							}
						}

						// CREATE DYNAMIC TABLE.
						var table = document.createElement("table");

						// CREATE HTML TABLE HEADER ROW USING THE EXTRACTED HEADERS ABOVE.

						var tr = table.insertRow(-1);			// TABLE ROW.
						
						var th = document.createElement("th");      // TABLE HEADER.
						th.innerHTML = "Row #";
						tr.appendChild(th);
						
						for (var i = 0; i < col.length; i++) {
							th = document.createElement("th");      // TABLE HEADER.
							th.innerHTML = col[i];
							tr.appendChild(th);
						}

						// ADD JSON DATA TO THE TABLE AS ROWS.
						for (var i = 0; i < myBooks.length; i++) {

							tr = table.insertRow(-1);
							var tabCell = tr.insertCell(-1);
							tabCell.id = count;
							tabCell.innerHTML = count;
							
							for (var j = 0; j < col.length; j++) {
								var tabCell = tr.insertCell(-1);
								tabCell.innerHTML = myBooks[i][col[j]];
							}
							count++;
						}

						// FINALLY ADD THE NEWLY CREATED TABLE WITH JSON DATA TO A CONTAINER.
						var divContainer = document.getElementById("result");
						divContainer.innerHTML = "";
						divContainer.appendChild(table);
						
						//$('#result').html(table);
						if(id != 0)
							$(window).scrollTop($('#' + id).offset().top);
					}
				});
			});
		</script>
	</body>
</html>